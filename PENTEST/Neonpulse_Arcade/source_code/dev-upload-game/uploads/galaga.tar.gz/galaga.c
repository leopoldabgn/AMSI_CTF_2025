/*
 * GALAGA - 1981 Namco
 * Game Source Code
 * 
 * Z80 Assembly translated to C for modern systems
 * Original hardware: Namco Galaga custom board with Z80 processor @ 3.072MHz
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

// Screen dimensions
#define SCREEN_WIDTH 224
#define SCREEN_HEIGHT 288
#define STARS_COUNT 64

// Game constants
#define MAX_ENEMIES 40
#define MAX_BULLETS 8
#define MAX_PLAYER_BULLETS 2
#define MAX_EXPLOSIONS 8
#define FORMATION_ROWS 5
#define FORMATION_COLS 10

// Game states
#define STATE_ATTRACT 0
#define STATE_STAGE_INTRO 1
#define STATE_GAMEPLAY 2
#define STATE_PLAYER_DEAD 3
#define STATE_GAME_OVER 4

// Enemy types
#define ENEMY_BEE 0
#define ENEMY_BUTTERFLY 1
#define ENEMY_BOSS 2

// Movement patterns
#define PATTERN_ENTRY 0
#define PATTERN_FORMATION 1
#define PATTERN_ATTACK 2
#define PATTERN_CAPTURED 3

// Sound effects - would be mapped to actual hardware addresses
#define SFX_SHOOT 0
#define SFX_EXPLOSION 1
#define SFX_ENEMY_SHOOT 2
#define SFX_CAPTURED 3
#define SFX_STAGE_INTRO 4

// Struct for player ship
typedef struct {
    int x, y;
    int lives;
    int capturedShip;  // Flag if player has a captured ship attached
    int respawnTimer;
    int invulnerableTimer;
} Player;

// Struct for enemies
typedef struct {
    int active;
    int type;  // 0=bee, 1=butterfly, 2=boss
    int x, y;
    int targetX, targetY;  // Formation position
    int patternIndex;
    int patternStep;
    int movementState;  // 0=entry, 1=formation, 2=attack, 3=captured
    int capturedShip;  // Flag if this enemy has captured a player ship
    int animFrame;
    int attackTimer;
    int value;  // Score value
} Enemy;

// Struct for bullets
typedef struct {
    int active;
    int x, y;
    int dx, dy;
    int isPlayerBullet;
} Bullet;

// Struct for explosions
typedef struct {
    int active;
    int x, y;
    int frame;
    int timer;
} Explosion;

// Game variables
Player player;
Enemy enemies[MAX_ENEMIES];
Bullet bullets[MAX_BULLETS];
Explosion explosions[MAX_EXPLOSIONS];
int stars[STARS_COUNT][3];  // x, y, brightness
int gameState;
int stageNumber;
int score;
int highScore;
int enemiesInFormation;
int enemiesRemaining;
int playerBulletCount;
int challengeStageMode;
int frameCounter;
int captureBeamActive;
int captureBeamX, captureBeamY, captureBeamLength;
int dualModeActive;

// Function prototypes
void initGame();
void initStage();
void updateGame();
void drawGame();
void processInput();
void updatePlayer();
void updateEnemies();
void updateBullets();
void updateExplosions();
void checkCollisions();
void firePlayerBullet();
void fireEnemyBullet(Enemy* enemy);
void triggerExplosion(int x, int y);
void createEnemy(int type, int patternIndex);
void moveEnemyInFormation(Enemy* enemy);
void moveEnemyInAttack(Enemy* enemy);
void activateCaptureBeam(Enemy* enemy);
void updateCaptureBeam();
void playSoundEffect(int sfx);

// Initializes the game state
void initGame() {
    memset(&player, 0, sizeof(Player));
    memset(enemies, 0, sizeof(enemies));
    memset(bullets, 0, sizeof(bullets));
    memset(explosions, 0, sizeof(explosions));
    
    player.lives = 3;
    player.x = SCREEN_WIDTH / 2;
    player.y = SCREEN_HEIGHT - 20;
    
    stageNumber = 1;
    score = 0;
    
    // Initialize stars for the background
    for (int i = 0; i < STARS_COUNT; i++) {
        stars[i][0] = rand() % SCREEN_WIDTH;  // x
        stars[i][1] = rand() % SCREEN_HEIGHT; // y
        stars[i][2] = rand() % 3;             // brightness (0-2)
    }
    
    gameState = STATE_ATTRACT;
    challengeStageMode = 0;
    dualModeActive = 0;
    captureBeamActive = 0;
    frameCounter = 0;
}

// Initializes a new stage
void initStage() {
    memset(enemies, 0, sizeof(enemies));
    memset(bullets, 0, sizeof(bullets));
    memset(explosions, 0, sizeof(explosions));
    
    player.x = SCREEN_WIDTH / 2;
    player.y = SCREEN_HEIGHT - 20;
    player.respawnTimer = 0;
    player.invulnerableTimer = 0;
    
    enemiesInFormation = 0;
    enemiesRemaining = 0;
    playerBulletCount = 0;
    challengeStageMode = (stageNumber % 3 == 0) ? 1 : 0;
    
    // Special challenge stage setup
    if (challengeStageMode) {
        // Setup challenge stage enemies
    } else {
        // Create regular stage enemies - 40 enemies in total
        for (int i = 0; i < 20; i++) createEnemy(ENEMY_BEE, i % 4);
        for (int i = 0; i < 16; i++) createEnemy(ENEMY_BUTTERFLY, (i % 4) + 4);
        for (int i = 0; i < 4; i++) createEnemy(ENEMY_BOSS, (i % 2) + 8);
        
        enemiesRemaining = 40;
    }
    
    gameState = STATE_STAGE_INTRO;
    playSoundEffect(SFX_STAGE_INTRO);
    frameCounter = 0;
}

// Main game update function
void updateGame() {
    frameCounter++;
    
    // Update stars (parallax scrolling)
    for (int i = 0; i < STARS_COUNT; i++) {
        // Move stars down at different speeds based on brightness
        stars[i][1] += stars[i][2] + 1;
        if (stars[i][1] >= SCREEN_HEIGHT) {
            stars[i][0] = rand() % SCREEN_WIDTH;
            stars[i][1] = 0;
            stars[i][2] = rand() % 3;
        }
    }
    
    // Process different game states
    switch (gameState) {
        case STATE_ATTRACT:
            // Update attract mode animation
            if (frameCounter > 600) {  // 10 seconds
                initGame();
            }
            break;
            
        case STATE_STAGE_INTRO:
            // Show "STAGE X" for a few seconds
            if (frameCounter > 180) {  // 3 seconds
                gameState = STATE_GAMEPLAY;
            }
            break;
            
        case STATE_GAMEPLAY:
            updatePlayer();
            updateEnemies();
            updateBullets();
            updateExplosions();
            
            if (captureBeamActive) {
                updateCaptureBeam();
            }
            
            checkCollisions();
            
            // Check if stage is complete
            if (enemiesRemaining <= 0) {
                stageNumber++;
                initStage();
            }
            break;
            
        case STATE_PLAYER_DEAD:
            // Player death animation
            updateEnemies();
            updateBullets();
            updateExplosions();
            
            if (frameCounter > 120) {  // 2 seconds after death
                if (player.lives <= 0) {
                    gameState = STATE_GAME_OVER;
                    frameCounter = 0;
                } else {
                    player.respawnTimer = 0;
                    player.invulnerableTimer = 180;  // 3 seconds of invulnerability
                    player.x = SCREEN_WIDTH / 2;
                    player.y = SCREEN_HEIGHT - 20;
                    gameState = STATE_GAMEPLAY;
                }
            }
            break;
            
        case STATE_GAME_OVER:
            // Game over animation
            if (frameCounter > 300) {  // 5 seconds
                gameState = STATE_ATTRACT;
                frameCounter = 0;
            }
            break;
    }
}

// Player ship control and update
void updatePlayer() {
    // Player ship logic would be here
    // Movement, shooting, respawn timers, etc.
}

// Enemy movement and behavior
void updateEnemies() {
    // Enemy movement patterns would be here
    // Different behaviors for different enemy types and movement states
}

// Main entry point - in a real game this would interface with hardware
int main() {
    srand(time(NULL));
    initGame();
    
    // Game loop
    while (1) {
        processInput();
        updateGame();
        drawGame();
        
        // Add a small delay to simulate the original game speed
        // In the actual arcade hardware, this would be synchronized with the display refresh
        // usleep(16667);  // ~60fps
    }
    
    return 0;
}
