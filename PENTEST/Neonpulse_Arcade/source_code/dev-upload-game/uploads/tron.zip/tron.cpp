/*
 * TRON - Bally Midway (1982)
 * Source code reconstruction - Light Cycle module
 * MCR Hardware platform - Z80 processor
 */

#include "system.h"
#include "graphics.h"
#include "sound.h"
#include "input.h"

// Global definitions
#define MAX_PLAYERS 4
#define GRID_SIZE 192
#define CYCLE_SPEED 3
#define WALL_COLOR_P1 0x0F
#define WALL_COLOR_P2 0x1C
#define WALL_COLOR_CPU1 0x2A
#define WALL_COLOR_CPU2 0x36

// Player structure
typedef struct {
    int x, y;
    int direction;  // 0=up, 1=right, 2=down, 3=left
    int speed;
    int alive;
    int score;
    int wall_color;
    int input_device;
} PLAYER;

// Game variables
PLAYER players[MAX_PLAYERS];
unsigned char grid[GRID_SIZE][GRID_SIZE];
int game_level = 1;
int bonus_timer = 999;
int active_players = 0;

// Hardware interface functions
void init_video_system();
void draw_grid_line(int x1, int y1, int x2, int y2, int color);
void play_sound_effect(int effect_id);
int read_player_input(int device_id);

// Game functions
void initialize_game() {
    int i, j;
    
    // Clear grid
    for (i = 0; i < GRID_SIZE; i++) {
        for (j = 0; j < GRID_SIZE; j++) {
            grid[i][j] = 0;
        }
    }
    
    // Initialize border walls
    for (i = 0; i < GRID_SIZE; i++) {
        grid[0][i] = 0xFF;
        grid[GRID_SIZE-1][i] = 0xFF;
        grid[i][0] = 0xFF;
        grid[i][GRID_SIZE-1] = 0xFF;
    }
    
    // Initialize players
    active_players = 2;  // Player 1 + CPU opponent
    
    // Player 1
    players[0].x = 20;
    players[0].y = 20;
    players[0].direction = 1;  // Right
    players[0].speed = CYCLE_SPEED;
    players[0].alive = 1;
    players[0].score = 0;
    players[0].wall_color = WALL_COLOR_P1;
    players[0].input_device = 0;
    
    // CPU Player
    players[1].x = GRID_SIZE - 20;
    players[1].y = GRID_SIZE - 20;
    players[1].direction = 3;  // Left
    players[1].speed = CYCLE_SPEED;
    players[1].alive = 1;
    players[1].score = 0;
    players[1].wall_color = WALL_COLOR_CPU1;
    players[1].input_device = -1;  // CPU controlled
    
    bonus_timer = 999;
}

void update_player_position(int player_id) {
    PLAYER *p = &players[player_id];
    
    if (!p->alive) return;
    
    // Read input if human player
    if (p->input_device >= 0) {
        int input = read_player_input(p->input_device);
        if (input & INPUT_UP && p->direction != 2) p->direction = 0;
        if (input & INPUT_RIGHT && p->direction != 3) p->direction = 1;
        if (input & INPUT_DOWN && p->direction != 0) p->direction = 2;
        if (input & INPUT_LEFT && p->direction != 1) p->direction = 3;
    } else {
        // CPU AI logic would go here
        cpu_ai_movement(player_id);
    }
    
    // Update position based on direction
    int old_x = p->x;
    int old_y = p->y;
    
    switch (p->direction) {
        case 0: p->y -= p->speed; break;  // Up
        case 1: p->x += p->speed; break;  // Right
        case 2: p->y += p->speed; break;  // Down
        case 3: p->x -= p->speed; break;  // Left
    }
    
    // Check collision
    if (grid[p->x][p->y] != 0) {
        p->alive = 0;
        play_sound_effect(SFX_CRASH);
        return;
    }
    
    // Draw light trail
    grid[p->x][p->y] = p->wall_color;
    draw_grid_line(old_x, old_y, p->x, p->y, p->wall_color);
}

// Main game loop - called by the system at 60Hz
void main_game_loop() {
    int i;
    
    // Update bonus timer
    if (bonus_timer > 0) bonus_timer--;
    
    // Update all active players
    for (i = 0; i < active_players; i++) {
        update_player_position(i);
    }
    
    // Check win condition
    int players_alive = 0;
    int last_alive = -1;
    
    for (i = 0; i < active_players; i++) {
        if (players[i].alive) {
            players_alive++;
            last_alive = i;
        }
    }
    
    if (players_alive <= 1) {
        if (last_alive >= 0) {
            players[last_alive].score += bonus_timer + 100;
        }
        initialize_game();
        game_level++;
    }
}