"""
Donkey Kong (1981) - Nintendo
Arcade game source code reconstruction
Z80 Assembly ported to Python for educational purposes
"""

import sys
import random
import time

# Game constants
SCREEN_WIDTH = 224
SCREEN_HEIGHT = 256
NUM_GIRDERS = 5
GRAVITY = 1.2
JUMP_FORCE = -12
BARREL_SPAWN_RATE = 65  # Higher number = fewer barrels

# Character sprites (simplified for text representation)
MARIO_SPRITE = [
    "    o    ",
    "   /|\\   ",
    "   / \\   "
]

KONG_SPRITE = [
    " @@@@@@@ ",
    "@       @",
    "@  o  o  @",
    "@   --   @",
    " @@@@@@@ "
]

BARREL_SPRITE = "O"

PRINCESS_SPRITE = [
    "   /\\   ",
    "  |~~|  ",
    "  \\__/  "
]

# Game state
class GameState:
    def __init__(self):
        self.lives = 3
        self.score = 0
        self.level = 1
        self.timer = 5000
        self.bonus = 5000
        
        # Mario position and state
        self.mario_x = 40
        self.mario_y = 225
        self.mario_vx = 0
        self.mario_vy = 0
        self.mario_facing = 1  # 1=right, -1=left
        self.mario_climbing = False
        self.mario_jumping = False
        
        # Kong position
        self.kong_x = 60
        self.kong_y = 40
        self.kong_animation_state = 0
        self.kong_barrel_throw_timer = 0
        
        # Princess position
        self.princess_x = 110
        self.princess_y = 32
        
        # Level structure
        self.girders = self.initialize_girders()
        self.ladders = self.initialize_ladders()
        
        # Barrels
        self.barrels = []
        
    def initialize_girders(self):
        """Create the level platforms"""
        girders = []
        # Bottom platform
        girders.append({"y": 230, "x_start": 0, "x_end": SCREEN_WIDTH})
        # Middle platforms
        girders.append({"y": 190, "x_start": 20, "x_end": SCREEN_WIDTH-20})
        girders.append({"y": 150, "x_start": 0, "x_end": SCREEN_WIDTH-40})
        girders.append({"y": 110, "x_start": 40, "x_end": SCREEN_WIDTH})
        # Top platform (Kong's platform)
        girders.append({"y": 70, "x_start": 0, "x_end": SCREEN_WIDTH-40})
        # Princess platform
        girders.append({"y": 40, "x_start": 100, "x_end": 140})
        return girders
    
    def initialize_ladders(self):
        """Create the ladders"""
        ladders = []
        ladders.append({"x": 40, "y_bottom": 190, "y_top": 150})
        ladders.append({"x": 180, "y_bottom": 190, "y_top": 150})
        ladders.append({"x": 70, "y_bottom": 150, "y_top": 110})
        ladders.append({"x": 130, "y_bottom": 150, "y_top": 110})
        ladders.append({"x": 100, "y_bottom": 110, "y_top": 70})
        ladders.append({"x": 180, "y_bottom": 110, "y_top": 70})
        ladders.append({"x": 120, "y_bottom": 70, "y_top": 40})
        return ladders

# Main game functions
def update_kong(game):
    """Update Kong's state and animations"""
    game.kong_animation_state = (game.kong_animation_state + 1) % 4
    
    # Throw barrel logic
    game.kong_barrel_throw_timer -= 1
    if game.kong_barrel_throw_timer <= 0:
        if random.randint(0, BARREL_SPAWN_RATE) == 0:
            throw_barrel(game)
            game.kong_barrel_throw_timer = 30

def throw_barrel(game):
    """Kong throws a new barrel"""
    barrel = {
        "x": game.kong_x + 20,
        "y": game.kong_y + 15,
        "vx": 2,
        "vy": 0,
        "on_ladder": False,
        "falling": False
    }
    game.barrels.append(barrel)

def update_barrels(game):
    """Update all barrel positions and states"""
    for barrel in game.barrels[:]:
        # Move barrel horizontally
        barrel["x"] += barrel["vx"]
        
        # Apply gravity if falling
        if barrel["falling"]:
            barrel["y"] += barrel["vy"]
            barrel["vy"] += GRAVITY
        
        # Check if barrel is on a girder
        on_girder = False
        for girder in game.girders:
            if (barrel["y"] + 5 >= girder["y"] and 
                barrel["y"] - 5 <= girder["y"] and 
                barrel["x"] >= girder["x_start"] and 
                barrel["x"] <= girder["x_end"]):
                barrel["y"] = girder["y"] - 5
                barrel["vy"] = 0
                barrel["falling"] = False
                on_girder = True
                break
        
        if not on_girder and not barrel["on_ladder"]:
            barrel["falling"] = True
            
        # Check if barrel reaches edge of girder
        if (on_girder and (barrel["x"] <= girder["x_start"] or 
                          barrel["x"] >= girder["x_end"])):
            barrel["falling"] = True
        
        # Check if barrel should go down a ladder
        if not barrel["on_ladder"] and random.randint(0, 30) == 0:
            for ladder in game.ladders:
                if (abs(barrel["x"] - ladder["x"]) < 10 and
                    barrel["y"] <= ladder["y_bottom"] and
                    barrel["y"] >= ladder["y_top"]):
                    barrel["on_ladder"] = True
                    barrel["falling"] = False
                    barrel["vy"] = 2  # move down ladder
                    barrel["vx"] = 0
                    barrel["x"] = ladder["x"]
                    break
        
        # Handle barrel on ladder
        if barrel["on_ladder"]:
            barrel["y"] += barrel["vy"]
            for ladder in game.ladders:
                if barrel["x"] == ladder["x"] and barrel["y"] >= ladder["y_bottom"]:
                    barrel["on_ladder"] = False
                    barrel["vx"] = random.choice([-2, 2])  # random direction after ladder
                    break
        
        # Remove barrels that fall off screen
        if barrel["y"] > SCREEN_HEIGHT:
            game.barrels.remove(barrel)
            
        # Check collision with Mario
        if (abs(barrel["x"] - game.mario_x) < 10 and
            abs(barrel["y"] - game.mario_y) < 10 and
            not game.mario_jumping):
            handle_mario_death(game)

def update_mario(game, keys):
    """Update Mario's position and state based on input"""
    # Handle horizontal movement
    if keys["left"] and not game.mario_climbing:
        game.mario_vx = -3
        game.mario_facing = -1
    elif keys["right"] and not game.mario_climbing:
        game.mario_vx = 3
        game.mario_facing = 1
    else:
        game.mario_vx = 0
    
    # Apply horizontal movement
    game.mario_x += game.mario_vx
    
    # Check ladder climbing
    game.mario_climbing = False
    if keys["up"] or keys["down"]:
        for ladder in game.ladders:
            if (abs(game.mario_x - ladder["x"]) < 10 and
                game.mario_y <= ladder["y_bottom"] and
                game.mario_y >= ladder["y_top"]):
                game.mario_climbing = True
                game.mario_x = ladder["x"]  # Center on ladder
                if keys["up"]:
                    game.mario_y -= 2
                if keys["down"]:
                    game.mario_y += 2
                break
    
    # Handle jumping
    if keys["jump"] and not game.mario_jumping and not game.mario_climbing:
        game.mario_jumping = True
        game.mario_vy = JUMP_FORCE
    
    # Apply gravity
    if not game.mario_climbing:
        game.mario_y += game.mario_vy
        if game.mario_jumping:
            game.mario_vy += GRAVITY
    
    # Check if Mario is on a girder
    if not game.mario_climbing:
        on_girder = False
        for girder in game.girders:
            if (game.mario_y + 12 >= girder["y"] and 
                game.mario_y - 5 <= girder["y"] and 
                game.mario_x >= girder["x_start"] and 
                game.mario_x <= girder["x_end"]):
                game.mario_y = girder["y"] - 12
                game.mario_vy = 0
                game.mario_jumping = False
                on_girder = True
                break
        
        if not on_girder and not game.mario_jumping:
            game.mario_jumping = True
            game.mario_vy = 0

def handle_mario_death(game):
    """Handle Mario losing a life"""
    game.lives -= 1
    if game.lives <= 0:
        game_over()
    else:
        # Reset Mario position
        game.mario_x = 40
        game.mario_y = 225
        game.mario_vx = 0
        game.mario_vy = 0
        game.mario_jumping = False
        game.mario_climbing = False
        
        # Clear barrels
        game.barrels = []

def check_level_complete(game):
    """Check if Mario reached the princess"""
    if (abs(game.mario_x - game.princess_x) < 15 and
        abs(game.mario_y - game.princess_y) < 15):
        game.score += game.bonus
        game.level += 1
        # Reset level with increased difficulty
        game.mario_x = 40
        game.mario_y = 225
        game.barrels = []
        game.bonus = 5000
        
        # Make game harder
        global BARREL_SPAWN_RATE
        BARREL_SPAWN_RATE = max(20, BARREL_SPAWN_RATE - 10)

def game_over():
    """Handle game over state"""
    print("GAME OVER")
    print(f"Final Score: {game.score}")
    sys.exit()

# Main game loop - would connect to rendering and input system
def main():
    game = GameState()
    keys = {"left": False, "right": False, "up": False, "down": False, "jump": False}
    
    while True:
        # In a real game, we'd get input here
        # ...
        
        # Update game state
        update_kong(game)
        update_barrels(game)
        update_mario(game, keys)
        check_level_complete(game)
        
        # Update timer and bonus
        game.timer -= 1
        if game.timer % 10 == 0:
            game.bonus = max(0, game.bonus - 10)
        
        if game.timer <= 0:
            handle_mario_death(game)
        
        # In a real game, we'd render here
        # ...
        
        time.sleep(0.016)  # ~60fps

if __name__ == "__main__":
    main()
