import pygame
import random
import sys

# Pac-Man Game - 1980 Namco
# Simple recreation for NeonPulse Arcade
# SynthKid - 2024

# Initialize pygame
pygame.init()

# Game constants
SCREEN_WIDTH = 448
SCREEN_HEIGHT = 496
TILE_SIZE = 16
GHOST_SCATTER_TIME = 7  # seconds
GHOST_CHASE_TIME = 20   # seconds

# Colors
BLACK = (0, 0, 0)
BLUE = (0, 0, 255)
WHITE = (255, 255, 255)
YELLOW = (255, 255, 0)
RED = (255, 0, 0)
PINK = (255, 184, 255)
CYAN = (0, 255, 255)
ORANGE = (255, 184, 82)

# Create the screen
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("PAC-MAN")
clock = pygame.time.Clock()

# Game variables
score = 0
lives = 3
level = 1
ghost_mode = "SCATTER"
mode_timer = 0

# Load maze layout from file
def load_maze():
    maze = [
        "XXXXXXXXXXXXXXXXXXXXXXXXXXXX",
        "X............XX............X",
        "X.XXXX.XXXXX.XX.XXXXX.XXXX.X",
        "XoXXXX.XXXXX.XX.XXXXX.XXXXoX",
        "X.XXXX.XXXXX.XX.XXXXX.XXXX.X",
        "X..........................X",
        "X.XXXX.XX.XXXXXXXX.XX.XXXX.X",
        "X.XXXX.XX.XXXXXXXX.XX.XXXX.X",
        "X......XX....XX....XX......X",
        "XXXXXX.XXXXX XX XXXXX.XXXXXX",
        "XXXXXX.XXXXX XX XXXXX.XXXXXX",
        "XXXXXX.XX          XX.XXXXXX",
        "XXXXXX.XX XXXXXXXX XX.XXXXXX",
        "XXXXXX.XX X      X XX.XXXXXX",
        "      .   X      X   .      ",
        "XXXXXX.XX X      X XX.XXXXXX",
        "XXXXXX.XX XXXXXXXX XX.XXXXXX",
        "XXXXXX.XX          XX.XXXXXX",
        "XXXXXX.XX XXXXXXXX XX.XXXXXX",
        "XXXXXX.XX XXXXXXXX XX.XXXXXX",
        "X............XX............X",
        "X.XXXX.XXXXX.XX.XXXXX.XXXX.X",
        "X.XXXX.XXXXX.XX.XXXXX.XXXX.X",
        "Xo..XX.......  .......XX..oX",
        "XXX.XX.XX.XXXXXXXX.XX.XX.XXX",
        "XXX.XX.XX.XXXXXXXX.XX.XX.XXX",
        "X......XX....XX....XX......X",
        "X.XXXXXXXXXX.XX.XXXXXXXXXX.X",
        "X.XXXXXXXXXX.XX.XXXXXXXXXX.X",
        "X..........................X",
        "XXXXXXXXXXXXXXXXXXXXXXXXXXXX"
    ]
    return maze

# Pacman class
class Pacman:
    def __init__(self):
        self.x = 14 * TILE_SIZE
        self.y = 23 * TILE_SIZE
        self.direction = "LEFT"
        self.next_direction = "LEFT"
        self.animation_frame = 0
        self.speed = 2
        
    def move(self, maze):
        # Check if next direction is possible
        if self.can_move(self.next_direction, maze):
            self.direction = self.next_direction
            
        # Move in current direction if possible
        if self.can_move(self.direction, maze):
            if self.direction == "LEFT":
                self.x -= self.speed
            elif self.direction == "RIGHT":
                self.x += self.speed
            elif self.direction == "UP":
                self.y -= self.speed
            elif self.direction == "DOWN":
                self.y += self.speed
                
        # Handle tunnel wrap-around
        if self.x < 0:
            self.x = SCREEN_WIDTH - TILE_SIZE
        elif self.x > SCREEN_WIDTH - TILE_SIZE:
            self.x = 0
            
    def can_move(self, direction, maze):
        # Check if the next position is a wall
        test_x, test_y = self.x, self.y
        
        if direction == "LEFT":
            test_x -= self.speed
        elif direction == "RIGHT":
            test_x += self.speed
        elif direction == "UP":
            test_y -= self.speed
        elif direction == "DOWN":
            test_y += self.speed
            
        # Convert position to grid coordinates
        grid_x = test_x // TILE_SIZE
        grid_y = test_y // TILE_SIZE
        
        # Check if the position is valid
        if grid_x < 0 or grid_x >= len(maze[0]) or grid_y < 0 or grid_y >= len(maze):
            return True  # Allow tunnel movement
            
        return maze[grid_y][grid_x] != "X"

# Ghost class
class Ghost:
    def __init__(self, color, x, y, target_func):
        self.color = color
        self.x = x
        self.y = y
        self.direction = "LEFT"
        self.target_func = target_func
        self.speed = 1.5
        self.frightened = False
        self.eaten = False
        
    def move(self, maze, pacman):
        # Ghost movement AI based on mode
        pass

# Main game loop
def main():
    maze = load_maze()
    pacman = Pacman()
    
    # Create ghosts
    blinky = Ghost(RED, 14*TILE_SIZE, 11*TILE_SIZE, lambda p: (p.x, p.y))
    pinky = Ghost(PINK, 14*TILE_SIZE, 14*TILE_SIZE, lambda p: (p.x + 4*TILE_SIZE if p.direction == "LEFT" else p.x - 4*TILE_SIZE, p.y))
    inky = Ghost(CYAN, 12*TILE_SIZE, 14*TILE_SIZE, lambda p, b: (2*(p.x) - b.x, 2*(p.y) - b.y))
    clyde = Ghost(ORANGE, 16*TILE_SIZE, 14*TILE_SIZE, lambda p, c: (p.x, p.y) if ((p.x-c.x)**2 + (p.y-c.y)**2)**0.5 > 8*TILE_SIZE else (0, 30*TILE_SIZE))
    
    ghosts = [blinky, pinky, inky, clyde]
    
    running = True
    while running:
        # Handle events
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    pacman.next_direction = "LEFT"
                elif event.key == pygame.K_RIGHT:
                    pacman.next_direction = "RIGHT"
                elif event.key == pygame.K_UP:
                    pacman.next_direction = "UP"
                elif event.key == pygame.K_DOWN:
                    pacman.next_direction = "DOWN"
        
        # Update game state
        pacman.move(maze)
        
        # Draw everything
        screen.fill(BLACK)
        
        # Update display
        pygame.display.flip()
        clock.tick(60)
    
    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main()

